/*	$RuOBSD: module.c,v 1.1 2004/11/01 05:00:44 form Exp $	*/

#include "module.h"


char *
module_entry(void)
{
	static char *id = MODULE_NAME " ($RuOBSD: module.c,v 1.1 2004/11/01 05:00:44 form Exp $)";

	return (id);
}
